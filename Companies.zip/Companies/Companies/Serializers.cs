using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Companies
{
    public abstract class MySerializer
    {
        public abstract IList<Company> Read(string fileName);

        public abstract void Write(IList<Company> companies, string fileName);
    }

    public class MyJsonSerializer : MySerializer
    {
        public override IList<Company> Read(string fileName)
        {
            try
            {
                if (File.Exists(fileName))
                {
                    return JsonSerializer.Deserialize<IList<Company>>(File.ReadAllText(fileName)) ?? new List<Company>();
                }
                else
                {
                    throw new Exception("���� �� ������!");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"�� ������� ��������� ����! �������: {ex.Message}");
            }
        }

        public override void Write(IList<Company> companies, string fileName)
        {
            try
            {
                File.WriteAllText(fileName, JsonSerializer.Serialize(companies));
            }
            catch (Exception ex)
            {
                throw new Exception($"������ � ���� �� �������. �������: {ex.Message}");
            }
        }
    }
}