﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Companies
{
    public partial class Company
    {
        public string Name { get; set; }
        public int MaxEmployeeCount { get; set; }
        public IList<Employee> Employees { get; set; }
        public Company()
        {
            Employees = new List<Employee>();
        }

        public void Hire(Employee employee)
        {
            Employees.Add(employee);
        }

        public void Fire(Employee employee)
        {
            Employees.Remove(employee);
        }
    }
}
