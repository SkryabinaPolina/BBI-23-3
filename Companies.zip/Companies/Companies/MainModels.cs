﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Companies
{
    public struct JobTitle
    {
        public string Name { get; set; }
        public double SalaryBonus { get; set; }
        public JobTitle()
        {

        }
    }

    public class Employee
    {
        public string Name { get; set; }
        public JobTitle JobTitle { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }
        public Employee()
        {

        }

        public override string ToString()
        {
            return $"Должность: {JobTitle.Name} {Name}, опыт работы: {Experience}, оклад: {Salary}";
        }
    }

    public class Manager : Employee, IPayble
    {
        public int ProjectsAmount { get; set; }
        public int Rank { get; set; }
        public int Bonus { get; set; }

        public double CalculateSalary()
        {
            return Salary + Bonus * JobTitle.SalaryBonus;
        }

        public override string ToString()
        {
            return base.ToString() + $", количество проектов: {ProjectsAmount}, ранг: {Rank}";
        }
    }
    public class Developer : Employee, IPayble
    {
        public int ProjectsAmount { get; set; }
        public int Rank { get; set; }
        public int Bonus { get; set; }

        public double CalculateSalary()
        {
            return Salary + Bonus * JobTitle.SalaryBonus;
        }

        public override string ToString()
        {
            return base.ToString() + $", количество проектов: {ProjectsAmount}, ранг: {Rank}";
        }
    }
    public class SalesPerson : Employee, IPayble
    {
        public int ProjectsAmount { get; set; }
        public int Rank { get; set; }
        public int Bonus { get; set; }

        public double CalculateSalary()
        {
            return Salary + Bonus * JobTitle.SalaryBonus;
        }

        public override string ToString()
        {
            return base.ToString() + $", количество проектов: {ProjectsAmount}, ранг: {Rank}";
        }
    }

    public interface IPayble
    {
        public double CalculateSalary();
    }

    public abstract class MySerializer
    {
        public abstract IList<Company> Read(string fileName);

        public abstract void Write(IList<Company> companies, string fileName);
    }
}
