﻿using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _7Laba_2Level_wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            WinterSport[] sports = { new FigureSkating(), new SpeedSkating() };
            var resultsList = new List<Result>();
            foreach (var sport in sports)
            {
                resultsList.Add(new Result { Description = $"Название дисциплины: {sport.DisciplineName}" });

                Participant[] participants = new Participant[5]
                {
                new Participant("Иван", new double[] { 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7 }, 0),
                new Participant("Петр", new double[] { 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7 }, 0),
                new Participant("Андрей", new double[] { 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7 }, 0),
                new Participant("Ксения", new double[] { 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7 }, 0),
                new Participant("Дарья", new double[] { 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7 }, 0)
                };

                for (int i = 0; i < participants.Length; i++)
                {
                    for (int j = 0; j < participants[i].GetScores().Length; j++)
                    {
                        int place = 1;
                        for (int k = 0; k < participants.Length; k++)
                        {
                            if (k != i && participants[i].GetScores()[j] < participants[k].GetScores()[j])
                            {
                                place++;
                            }
                        }
                        int b = participants[i].GetSumOfPlaces();
                        b += place;
                        participants[i].SetSumOfPlaces(b);
                    }
                }

                var orderedParticipants = participants.OrderBy(p => p.GetSumOfPlaces());

                foreach (var participant in orderedParticipants)
                {
                    resultsList.Add(new Result { Description = $"Имя: {participant.GetName()}, Сумма: {participant.GetSumOfPlaces()}" });
                }
            }
            DataContext = new ResultsViewModel(resultsList);
            InitializeComponent();
        }
    }

    public abstract class WinterSport
    {
        public abstract string DisciplineName { get; }
    }

    public class FigureSkating : WinterSport
    {
        public override string DisciplineName
        {
            get { return "Фигурное катание"; }
        }
    }

    public class SpeedSkating : WinterSport
    {
        public override string DisciplineName
        {
            get { return "Конькобежный спорт"; }
        }
    }

    public class Participant
    {
        private string Name;
        private double[] Scores;
        private int SumOfPlaces;

        public Participant(string name, double[] scores, int sum)
        {
            Name = name;
            Scores = scores;
            SumOfPlaces = sum;
        }

        public string GetName() => Name;
        public double[] GetScores() => Scores;
        public int GetSumOfPlaces() => SumOfPlaces;

        public void SetSumOfPlaces(int sum)
        {
            SumOfPlaces = sum;
        }
    }

    public class Result
    {
        public string Description { get; set; }
        public Result()
        {

        }
    }

    public class ResultsViewModel : DependencyObject
    {


        public ICollectionView Items
        {
            get { return (ICollectionView)GetValue(MyPropertyProperty); }
            set { SetValue(MyPropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MyPropertyProperty =
            DependencyProperty.Register("MyProperty", typeof(ICollectionView), typeof(ResultsViewModel), new PropertyMetadata(null));

        public ResultsViewModel(IList<Result> results)
        {
            Items = CollectionViewSource.GetDefaultView(results);
        }
    }
}